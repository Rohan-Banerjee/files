package moderation;

import java.net.URI;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class Instagram {
	
	public ArrayList<String> generateTimeLine() {
		
		// TODO Auto-generated method stub
		HttpClient httpclient = HttpClients.createDefault();
		ArrayList<String> posts = new ArrayList<>();
		try {
		URIBuilder builder = new URIBuilder("https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url&access_token=IGQVJXcm1ZANmZAZAUnVkcFVfeENrRkZASdVVCUVM1LVpib3piXzdmVFV0R1d5anBYLWZAFTVRLdHVhOHU4X0M5ZAkxtX3FpRlhrb0lNSzN6RHVOdWFxMDRNU0FMOHBlcUhaVmlDMVVaUXBmbjFVaUpINEN1MQZDZD");
		
		URI uri = builder.build();
		HttpGet request = new HttpGet(uri);
		//HttpPost request= new HttpPost(uri);
		
		 
		 //get response
		 HttpResponse response = httpclient.execute(request);
		 HttpEntity entity = response.getEntity();
		 
		 if(entity!=null)
		 {
			 int i; 
			 String s = EntityUtils.toString(entity);
			 JSONObject object = new JSONObject(s);
			 JSONArray data = object.getJSONArray("data");
			 if(data.length()>0)
			 {
				 for(i=0;i<data.length();i++)
				 {
					 JSONObject info = data.getJSONObject(i);
					 if(info.has("caption"))
					 {
						 String caption = info.getString("caption");
						 posts.add(caption); 
						 String m_type = info.getString("media_type");
						 if(m_type.equalsIgnoreCase("image"))
						 {
							 String m_url = info.getString("media_url");
							 posts.add(m_url);
						 }
						 else
						 {
							 posts.add("0");
						 }
					 }
					 
				 }
				 return posts;
			 }
		 }
		return posts;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			posts.add("error");
			return posts;
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Instagram i = new Instagram();
		System.out.println(i.generateTimeLine());
	}

}

package moderation;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SightEngine {
	
	public ArrayList<String> textModerate(String content, String lang) throws IOException
	{
		ArrayList<String> ar = new ArrayList<>();
		try { 
		String api_secret = "xNgpQfNNCqoBCdVN4uax";
		String api_user = "1091784875";
		String text = content;
		String mode ="standard";
		String url = "https://api.sightengine.com/1.0/text/check.json";
		    OkHttpClient client = new OkHttpClient();
		            RequestBody requestBody = new MultipartBody.Builder()
		            .setType(MultipartBody.FORM)
		            .addFormDataPart("api_user", api_user)
		            .addFormDataPart("text", text)
		            .addFormDataPart("api_secret", api_secret)
		            .addFormDataPart("mode", mode)
		            .addFormDataPart("lang", lang)
		            .build();
		            Request request = new Request.Builder()
		              .url(url)
		              .post(requestBody)
		              .addHeader("cache-control", "no-cache")
		              .build();
		Response response = client.newCall(request).execute();
		String s = response.body().string();
		
		JSONObject object = new JSONObject(s);
		 JSONObject profanity = object.getJSONObject("profanity");
		 JSONArray matches = profanity.getJSONArray("matches");
		 int i;
		 if(matches.length()>0)
		 {
			for(i=0;i<matches.length();i++)
			{
				JSONObject match = matches.getJSONObject(i);
				String type = match.getString("type");
				String word = match.getString("match");
				ar.add(word);
				ar.add(type);	
			}
			return ar;
		 }
		 else
		 {
			 ar.add("|empty|");
			 return ar;
		 }
		}catch(Exception e)
		{
			ar.add("error");
			return ar;
		}
		
	}

	public ArrayList<String> v_moderate(String v_url, String model_name) {
		// TODO Auto-generated method stub
		HttpClient httpclient = HttpClients.createDefault();
		
		try {
		URIBuilder builder = new URIBuilder("https://api.sightengine.com/1.0/video/check-sync.json?models="+model_name+"&api_user=1908761413&api_secret=p7rkYM77TUZfsfjtEwi4&stream_url="+v_url);
		
		URI uri = builder.build();
		HttpPost request= new HttpPost(uri);
		
		 
		 //get response
		 HttpResponse response = httpclient.execute(request);
		 HttpEntity entity = response.getEntity();
		 
		 if(entity!=null)
		 {
			 String s = EntityUtils.toString(entity);
			 JSONObject object = new JSONObject(s);
			 JSONObject data = object.getJSONObject("data");
			 JSONArray frames = data.getJSONArray("frames");
			 if(model_name.equalsIgnoreCase("wad"))
			 {
				 double weapon,alcohol,drugs;
				 ArrayList <String> ar = new ArrayList<>();
				 int i=0;
				 while(i<frames.length())
				 {
				 JSONObject element = frames.getJSONObject(i);
				 weapon = element.getDouble("weapon");
				 alcohol = element.getDouble("alcohol");
				 drugs = element.getDouble("drugs");
				 
				 if(weapon>0.1)
				 ar.add("Weapon at frame:"+i+"000 is: "+weapon);
				 if(alcohol>0.1)
				 ar.add("Alchohol at frame:"+i+"000 is: "+alcohol);
				 if(drugs>0.1)
				 ar.add("Drugs at frame:"+i+"000 is: "+drugs);
				 
				 i++;
				 }
				 return ar;
			 }
			 else
			 {
				 
			 
			 int i=0;
			 double raw_nudity;
			 double partial_nudity;
			 ArrayList<String> ar = new ArrayList<>();
			 while(i<frames.length())
			 {
			 JSONObject element = frames.getJSONObject(i);
			 JSONObject nudity = element.getJSONObject("nudity");
			 raw_nudity = nudity.getDouble("raw");
			 partial_nudity = nudity.getDouble("partial");
			 
			 if(raw_nudity>0.1)
			 ar.add("Raw Nudity at frame:"+i+"000 is: "+raw_nudity);
			 
			 if(partial_nudity>0.1)
			 ar.add("Partial Nudity at frame:"+i+"000 is: "+partial_nudity);
			 
			 i++;
			 }
			 return ar;
			 }
		}
		}
		catch (Exception e)
		{
			ArrayList<String> ar = new ArrayList<>();
			ar.add("error");
			return ar;
		}
		return null;
			
}
	
	public String imageModeration(String url)
	{
		
		int image_safe=0;
		HttpClient httpclient = HttpClients.createDefault();
		ArrayList<String> ar = new ArrayList<>();
		try {
		URIBuilder builder = new URIBuilder("https://api.sightengine.com/1.0/check.json?&api_user=1908761413&api_secret=p7rkYM77TUZfsfjtEwi4&models=nudity,wad&url="+url);
		
		URI uri = builder.build();
		HttpGet request= new HttpGet(uri);
		
		 
		 //get response
		 HttpResponse response = httpclient.execute(request);
		 HttpEntity entity = response.getEntity();
		 
		 if(entity!=null)
		 {
			 int i; 
			 String s = EntityUtils.toString(entity);
			 JSONObject object = new JSONObject(s);
				 JSONObject nudity = object.getJSONObject("nudity");
				 Double raw = nudity.getDouble("raw");
				 raw = (double) Math.round(raw * 100);
				 Double safe = nudity.getDouble("safe");
				 safe = (double) Math.round(safe * 100);
				 Double partial = nudity.getDouble("partial");
				 partial = (double) Math.round(partial * 100);
				
				 
			 Double weapon = object.getDouble("weapon");
			 weapon = (double) Math.round(weapon * 100);
			 Double alcohol = object.getDouble("alcohol");
			 alcohol = (double) Math.round(alcohol * 100);
			 Double drugs = object.getDouble("drugs");
			 drugs = (double) Math.round(drugs * 100);
			 
			 if(raw > safe && raw >partial && raw > weapon && raw > alcohol && raw > drugs && raw > 20)
			 {
				return "Raw Nudity "+raw;
			 }
			 else if(partial > safe && partial > raw && partial > weapon && raw > alcohol && partial > drugs && partial > 20)
			 {
				return "Partial Nudity "+partial;
			 }
			 else if(weapon > safe && weapon > raw && weapon > partial && weapon > alcohol && weapon > drugs && weapon > 20)
			 {
				 return "Weapon "+weapon; 
			 }
			 else if(alcohol > safe && alcohol > raw && alcohol > partial && alcohol > weapon && alcohol > drugs && alcohol > 20)
			 {
				 return "Alcohol "+alcohol;
			 }
			 else if(drugs > safe && drugs > raw && drugs > partial && drugs > weapon && drugs > alcohol && drugs > 20)
			 {
				 return "Drugs "+drugs;
			 }
			 else
			 {
				 return "Safe";
			 }
			
}
		 else {
			 return "error";
		 }
	}
		catch(Exception  e)
		{
			return "error";
		}
	}
	public static void main(String args[]) throws IOException
	{
		SightEngine se = new SightEngine();
		String msg="Few dictionary analize . travelled from bangalore to California via assam.";
		msg = msg.replaceAll("\\s", "+");
		msg= msg.replaceAll("[^a-zA-Z0-9]", "+");
		System.out.println(se.textModerate(msg, "en"));
	}
}
		

package moderation;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mongodb.util.JSON;


@Controller
public class controller {
	
	//global lists for twitter
	ArrayList<String> toxicity = new ArrayList<>();
	ArrayList<Double> toxicity_value = new ArrayList<>();
	ArrayList<String> image_res = new ArrayList<>();
	ArrayList<String> intents = new ArrayList<String>();
	ArrayList<String> sentiments = new ArrayList<String>();
	ArrayList<String> emotions = new ArrayList<String>();
	ArrayList<ArrayList<String>> moderatedText2= new ArrayList<>(); 
	ArrayList<ArrayList<String>> type = new ArrayList<>();
	
	
	ArrayList<String> list = new ArrayList<String>();
	ArrayList<String> list1 = new ArrayList<String>();
	ArrayList<String> list2= new ArrayList<String>();
	ArrayList<String> list3= new ArrayList<String>();
	
	//Global lists for youtube
	ArrayList<String>  ylist1 = new ArrayList<String>();
	ArrayList<String> ylist2= new ArrayList<String>();
	ArrayList<String> listtwo= new ArrayList<String>();

	//global lists for facebook
	ArrayList<String> flist1 = new ArrayList<String>();
	ArrayList<String> flist2 = new ArrayList<String>();
	ArrayList<ArrayList<String>> moderated = new ArrayList<>();
	ArrayList<String> listone = new ArrayList<String>();
	ArrayList<String> fblist = new ArrayList<String>();
	
	@RequestMapping("/gotoHome")
	public String redirect1(Model model) {
		
		return "home";
	}	
	
	@RequestMapping("/gotoSearchOccurrences")
	public String redirect2(Model model) {
		
		return "searchOccurrences";
	}
	
	@RequestMapping("/gotoSearchQuery")
	public String redirect3(Model model) {
		
		return "twitterSearch";
	}
	
	@RequestMapping("/gotoCommentList")
	public String redirect4(Model model) {
		
		return "commentList";
	}
	@RequestMapping("/gotoFetchYoutubeVideos")
	public String redirect5(Model model) {
		
		return "fetchYoutubeVideos";
	}
	
	@RequestMapping("/createTwitterGraph")
	public String createTwitterGraph(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getTweetsfromDB();
		//response = doc;
		//response = db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			
			response=doc;
		}
		
		
		JSONArray response_image = new JSONArray();
		//response_image = doc2;
		response_image = db.getImagefromDB();
		//response_image = db.readImagesfromJSON();
		System.out.println(response_image);
		
		int l, obj_image =0, safe_image=0, count_img=0;
		for(l=0;l<response_image.length();l++)
		{
			String s = response_image.get(l).toString();
			JSONObject j = new JSONObject(s);
			if(j.has("error"))
			{
				//throw error
			}
			else
			{
				count_img++;
				if(!(j.getString("review").equalsIgnoreCase("yes")))
				{
					safe_image++;
				}
				else
				{
					obj_image++;
				}
			}
			
			
		}
		JSONArray image = new JSONArray();
		JSONObject image_data1 = new JSONObject();
		
		image_data1.put("category","Safe Images");
		image_data1.put("value", safe_image);
		image.put(image_data1);		
		
JSONObject image_data2 = new JSONObject();
		
		image_data2.put("category","Review Recommended");
		image_data2.put("value", obj_image);
		image.put(image_data2);
		
		model.addAttribute("image", image);
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
				
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray images_vs_text = new JSONArray();
		JSONObject images = new JSONObject();
		
		images.put("category","Images");
		images.put("value", count_img);
		images_vs_text.put(images);
		
JSONObject texts = new JSONObject();
		
		texts.put("category","Texts");
		texts.put("value", count);
		images_vs_text.put(texts);
		
		model.addAttribute("image_vs_texts", images_vs_text);
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "twitterDashboards");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Complaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		
		}
		catch(Exception e)
		{
			return "twitterCharts";
		}
		
		return "twitterCharts";
	}
	
	@RequestMapping("/createFacebookGraph")
	public String createFaceBookGraph(Model model, JSONArray doc) throws IOException {
		
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0, complaint=0 ;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getFbPostsfromDB();
		//response =db.readcontentfromJSON();
		//response = docs;
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++; 
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "twitterDashboards");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Complaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		
		System.out.println("Emotion"+emotion);
		}
		catch(Exception e)
		{
		return "facebookCharts";
		}
		return "facebookCharts";
	}
	
	@RequestMapping("/getfbcc")
	public void getFacebookcc(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getFbPostsfromDB();
		//response =db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
							
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "twitterDashboards");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data5.put("category", "Complaint");
		intent_data5.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data1.put("category", "Excited");
		emotion_data1.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("fbintent", intent);
		model.addAttribute("fbsentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		}
		catch(Exception e)
		{
			
		}
		
	}
	
	@RequestMapping("/gotoTwittercc")
	public void getTwittercc(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getTweetsfromDB();

		//response = db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		JSONArray response_image = new JSONArray();
		response_image = db.getImagefromDB();
		//response_image = db.readImagesfromJSON();
		System.out.println(response_image);
		
		int l, obj_image =0, safe_image=0, count_img=0;
		for(l=0;l<response_image.length();l++)
		{
			String s = response_image.get(l).toString();
			JSONObject j = new JSONObject(s);
			if(j.has("error"))
			{
				//throw error
			}
			else
			{
				count_img++;
				if(!(j.getString("review").equalsIgnoreCase("yes")))
				{
					safe_image++;
				}
				else
				{
					obj_image++;
				}
			}
			
			
		}
		JSONArray image = new JSONArray();
		JSONObject image_data1 = new JSONObject();
		
		image_data1.put("category","Safe Images");
		image_data1.put("value", safe_image);
		image.put(image_data1);		
		
JSONObject image_data2 = new JSONObject();
		
		image_data2.put("category","Review Recommended");
		image_data2.put("value", obj_image);
		image.put(image_data2);
		
		model.addAttribute("image", image);
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
								
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray images_vs_text = new JSONArray();
		JSONObject images = new JSONObject();
		
		images.put("category","Images");
		images.put("value", count_img);
		images_vs_text.put(images);
		
JSONObject texts = new JSONObject();
		
		texts.put("category","Texts");
		texts.put("value", count);
		images_vs_text.put(texts);
		
		model.addAttribute("image_vs_texts", images_vs_text);
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "twitterDashboards");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data5.put("category", "Complaint");
		intent_data5.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data1.put("category", "Excited");
		emotion_data1.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("twitterintent", intent);
		model.addAttribute("twittersentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		}
		catch(Exception e)
		{
			
		}
		
	}
	
	@RequestMapping("/createInstaGraph")
	public String createInstagramGraph(Model model, JSONArray doc) throws IOException {
		
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0, complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		Database db = new Database();
		response = db.getInstaPostsfromDB();
		//response = db.readinstafromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "twitterDashboards");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data5.put("category", "Complaint");
		intent_data5.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);

		return "instagramCharts";
		}
		catch(Exception e)
		{
			return "instagramCharts";
		}
	}
	

	@RequestMapping("/createYoutubeGraph")
	public String createYoutubeGraph(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0, complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		Database db = new Database();
		response = db.getYoutubeCommentsfromDB();
		//response = db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "twitterDashboards");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Comaplaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		}
		catch(Exception e)
		{
			return "youTubeCharts";
		}
		return "youTubeCharts";
		
	}
		
	
	@RequestMapping("/gotoYoutubecc")
	public void getYoutubecc(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getYoutubeCommentsfromDB();
		//response = db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;	
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "twitterDashboards");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Complaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("youtubeintent", intent);
		model.addAttribute("youtubesentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		}
		catch(Exception e)
		{
			
		}
	}
	
	@RequestMapping("/populateCommandCenter")
	public String populateCommandCenter( Model model) throws java.lang.Exception {
		JSONArray ar = new JSONArray();
		getFacebookcc(model,ar);
		getTwittercc(model,ar);
		getYoutubecc(model,ar);
	return "commandCenter";
	
	}
		
	@RequestMapping("/generateTimeline")
	public String generateTimeline(Model model) throws java.lang.Exception {
		try {
		TwitterClass f = new TwitterClass();
		list.clear();
		list1.clear();
		list2.clear();
		list3.clear();
		list = f.getTimeLine();
		int i=0;
		if(list.get(0).toString().equalsIgnoreCase("error"))
		{
			model.addAttribute("err","Server Overloaded.");
			return "twitterDashboard";
		}
		while(i<list.size())
		{
			list1.add(list.get(i));
			list2.add(list.get(i+1));
			list3.add(list.get(i+2));
			i=i+3;
		}
		model.addAttribute("message",list1);
		model.addAttribute("message1", list2);
		model.addAttribute("message2", list3);	
		
		
		moderateTwittertext(model,list1,list2,list3);
		}
		catch(Exception e)
		{
			model.addAttribute("err","Server Overloaded.");
			return "twitterDashboard";
		}
		
		return "twitterDashboard";
	}
	
	@RequestMapping("/checkLogin")
	public String checkLogin(@RequestParam String email,String pass, Model model) throws java.lang.Exception {
		
		Database db = new Database();
		int response = db.checkLogin(email,pass);
		if(response==1)
		{
			return "home";
		}
		else
		{
			return "tryAgain";
			
		}
	}
	@RequestMapping("/searchOccurrence")
	
	public String searchOccurrence(@RequestParam String word, Model model) throws java.lang.Exception {
		
	
		ArrayList<String> message = new ArrayList<>();
		ArrayList<String> message1 = new ArrayList<>();
		ArrayList<String> message2 = new ArrayList<>();
		ArrayList<String> statuses = new ArrayList<>();
		
		word= word.toLowerCase();
		TwitterClass f = new TwitterClass();
		statuses = f.getTimeLine();
		int i=0, count = 0 ;
		
		int j=0;
		while(j<statuses.size())
		{
			message.add(statuses.get(j));
			message1.add(statuses.get(j+1));
			message2.add(statuses.get(j+2)+":small");
			j=j+3;
		}
		for(i=0;i<statuses.size();i++)
		{
			if(statuses.get(i).toLowerCase().contains(word))
			{
				statuses.indexOf(word);
				count++;
			}
		}
		
		model.addAttribute("list1", message);
		model.addAttribute("list2", message1);
		model.addAttribute("list3", message2);
		model.addAttribute("Count", "Count found= "+count);
		return "searchOccurrences";
		
	}
	
	@RequestMapping("/moderateTwitterText")
	public String moderateTwittertext(Model model,ArrayList<String> listone,ArrayList<String> listtwo, ArrayList<String> listthree) throws Exception{
	try {
		toxicity.clear();
		image_res.clear();
		toxicity_value.clear();
		intents.clear();
		sentiments.clear();
		emotions.clear();
		moderatedText2.clear();
		
		int length_list;
		
		ArrayList<String> child = new ArrayList<>();
		ArrayList<ArrayList<String>> type = new ArrayList<>();
		if(listone.size()>=5)
		{
			length_list=5;
		}
		else
		{
			length_list = listone.size();
		}
		int i =0 ; 
		while(i!=length_list)
		{
			String result = "Safe";
			//sentiment analysis
			ParallelDots pd = new ParallelDots();
			String emo= pd.emotionDetect(listtwo.get(i).toString());
			emotions.add(emo);
			String intent = pd.intentAnalysisOld(listtwo.get(i).toString());
			intents.add(intent);
			String sentiment = pd.evalSentiment(listtwo.get(i).toString());
			sentiments.add(sentiment);
			
			
			//if image present evaluate image
			if(!(listthree.get(i).toString().equalsIgnoreCase("0")))
			{

				ModerateContent mc = new ModerateContent();
				String url = listthree.get(i).toString();
				result = mc.moderateImage(url);
				image_res.add(result);

			}
			else
			{
				image_res.add("No image");
			}
			

			  //text moderate
			  BadWords bd = new BadWords();
				String msg = listtwo.get(i).toString(); 
				child = bd.moderateText(msg, "en");
				ArrayList<String> type_child = new ArrayList<>();
				if(child.get(0).equalsIgnoreCase("No Bad Words"))
				{
					toxicity.add("No");
					type_child.add("Appropriate");
					
				}
				else
				{
					toxicity.add("Yes");
					int iter=1;
					while(iter<child.size())
					{
						type_child.add(child.get(iter).toString());
						iter= iter +2;
					}
					
				}
				type.add(type_child);
				moderatedText2.add(child);			
			
			i++;
		}

		  model.addAttribute("moderateText",moderatedText2);
			 
			model.addAttribute("intent", intents);
			model.addAttribute("emotion", emotions);
			model.addAttribute("sentiment", sentiments);
			model.addAttribute("original", listtwo);
			model.addAttribute("toxicity", toxicity);
			model.addAttribute("image_res", image_res);
	}
	catch(Exception e)
	{
		model.addAttribute("err", "Server overload !");
		return "twitterDashboard";
	}

		return "twitterDashboard";
	}
	
	@RequestMapping("/search")
	public String searchTwitter(Model model, String query) throws java.lang.Exception {
			if(query.isEmpty())
			{
				model.addAttribute("err", "No String present");
				return "twitterSearch";
			}
			
			list.clear();
			list1.clear();
			list2.clear();
			list3.clear();
			TwitterClass f = new TwitterClass();
//			List<String> list=new ArrayList<String>(50);
//			List<String> list1=new ArrayList<String>(15);
//			List<String> list2=new ArrayList<String>(15);
//			List<String> list3=new ArrayList<String>(15);
			list = f.searchtweets(query);
			int i=0;
			if(list.get(0).equalsIgnoreCase("error"))
			{
			model.addAttribute("err", "Server overloaded!");
		    return "twitterSearch";
			}
			while(i<list.size())
			{
				list1.add(list.get(i));
				list2.add(list.get(i+1));
				list3.add(list.get(i+2));
				i=i+3;
			}
			model.addAttribute("message",list1);
			model.addAttribute("message1", list2);
			model.addAttribute("message2", list3);
			
			moderateTwittertext(model,list1,list2,list3);
			
			return "twitterSearch";
		
		
	}
		
	@RequestMapping("/new")
	public String fetchCommentsUsingVid(Model model,String vid) throws Exception {
			System.out.println("Inside new");
			String num= "5";
			System.out.println(vid);
			if(vid.isEmpty() || num.isEmpty())
			{
				model.addAttribute("message","Fields cannot be empty!");
				return "commentList";
			}
		
			int number = Integer.parseInt(num);
			if(number > 100)
			{
				model.addAttribute("message","Cannot fetch more than 100 comments.");
				return "commentList";
			}
			else if(number<0)
			{
				model.addAttribute("message","Number of comments cannot be below 0.");
				return "commentList";
			}
			ApiExample ap = new ApiExample();
			ArrayList<String> ar = new ArrayList<String>();
			ArrayList<String> list1 = new ArrayList<String>();
			ArrayList<String> list2 = new ArrayList<String>();
			ar =  ap.fetchCommentsUsingVid(vid, number);
			if(ar.size()==1)
			{
				if(ar.get(0).equalsIgnoreCase("error"))
				{
				model.addAttribute("message", "Oh! Your video wasn't found. Please enter a valid URL.");
			    return "commentList";
				}
			}
			int i=0;
			while(i<ar.size())
			{
				list1.add(ar.get(i));
				list2.add(ar.get(i+1));
				i=i+2;
			}
			model.addAttribute("message",list1);
			model.addAttribute("message1", list2);
			ylist1=list1;
			ylist2=list2;
			moderateYoutubeText(model,list1,list2);
			return "commentList";
		}
		
		
		@RequestMapping("/fetchFacebookPagePosts")
	public String fetchFacebookPagePosts(Model model) throws Exception {
			ArrayList<String> posts = new ArrayList<>();
			FacebookHttp face = new FacebookHttp();
			posts = face.getPagePosts();
			if(posts.get(0).toString().equalsIgnoreCase("error"))
			{
				model.addAttribute("err","Server overloaded!");
				return  "fetchFacebookPagePosts";
			}
			else
			{
				System.out.println("reached here");
				moderateFacebookText(model, posts);
				model.addAttribute("message", posts);
				return "fetchFacebookPagePosts";
				
			}
			
		}
		
	@RequestMapping("/fetchFacebookTimeline")
	public String fetchFacebookTimeline(Model model) throws java.lang.Exception {
			fblist.clear();
			FacebookHttp fb =new FacebookHttp();
			fblist = fb.getUserTimeline();
			if(fblist.get(0).toString().equalsIgnoreCase("error"))
			{
				model.addAttribute("err","Server overloaded!");
				return "fetchFacebookTimeline";
			}
			
			model.addAttribute("message", fblist);
			moderateFacebookText(model, fblist);
			return "fetchFacebookTimeline";
		}
		
		@RequestMapping("/fetchInstaTimeline")
	public String fetchInstaTimeline(Model model) {
			try {
				Instagram in = new Instagram();
				list.clear();
				list1.clear();
				list2.clear();
				list = in.generateTimeLine();
				int i=0;
				if(list.get(0).toString().equalsIgnoreCase("error"))
				{
					model.addAttribute("err","Server Overload");
					return "fetchInstaTimeline";
				}
				while(i<list.size())
				{
					list1.add(list.get(i));
					list2.add(list.get(i+1));
					i=i+2;
				}
				model.addAttribute("message",list1);
				model.addAttribute("message2", list2);		
				moderateTwittertext(model,list1,list1,list2);
				}
				catch(Exception e)
				{
					model.addAttribute("err", "Server Overload!+");
				}			
				return "fetchInstaTimeline";
		}
		
	
		@RequestMapping("/moderateYoutubeText")
	public String moderateYoutubeText(Model model, ArrayList<String> list1, ArrayList<String> list2) throws Exception{
			try {
			ArrayList<String> child = new ArrayList<>();
			
			ArrayList<ArrayList<String>> type = new ArrayList<>();
			emotions.clear();
			sentiments.clear();
			intents.clear();
			moderatedText2.clear();
			toxicity.clear();
			toxicity_value.clear();
			listone.clear();
			listtwo.clear();
			listone=list1;
			listtwo=list2;
		
			
			int i =0 ; 
			while(i<5)
			{
				//sentiment analysis
				ParallelDots pd = new ParallelDots();
				String emo= pd.emotionDetect(list2.get(i).toString());
				emotions.add(emo);
				String intent = pd.intentAnalysisOld(list2.get(i).toString());
				intents.add(intent);
				String sentiment = pd.evalSentiment(list2.get(i).toString());
				sentiments.add(sentiment);
				
				
				//text moderate
				SightEngine se1 = new SightEngine();
				String msg = listtwo.get(i).toString();
				msg= msg.replaceAll("[^a-zA-Z0-9]", "+");  
				child = se1.textModerate(msg, "en");
				ArrayList<String> type_child = new ArrayList<>();
				if(child.get(0).equalsIgnoreCase("|empty|"))
				{
					toxicity.add("No");
					child.add(0, "No Bad Words");
					child.add("-");
					type_child.add("-");
					
				}
				else
				{
					toxicity.add("Yes");
					int iter=1;
					while(iter<child.size())
					{
						type_child.add(child.get(iter).toString());
						iter= iter +2;
					}
					
				}
				type.add(type_child);
				moderatedText2.add(child);			
				System.out.println("Moderated text2= "+moderatedText2);
			
				
				/*
				 * BadWords bd = new BadWords(); child = bd.moderateText(list2.get(i), "en");
				 * if(child.get(0).toString().equalsIgnoreCase("Nothing found")) { child.add(0,
				 * "No Bad words"); } moderatedText2.add(child);
				 */
				
				
					i++;
			}


				model.addAttribute("moderateText", moderatedText2);
				model.addAttribute("emotion", emotions);
				model.addAttribute("sentiment", sentiments);
				model.addAttribute("intent", intents);
				model.addAttribute("original", list2);
				model.addAttribute("toxicity", toxicity);
				model.addAttribute("type", type);
			return "commentList";
			}
			catch(Exception e)
			{
				model.addAttribute("err", "Server overloaded");
				return "commentList";
			}
			
		}
		
	@RequestMapping("/moderateFacebookText")
	public String moderateFacebookText(Model model, ArrayList list1) throws Exception {
			try {
			ArrayList<String> child = new ArrayList<>();
			toxicity.clear();
			emotions.clear();
			sentiments.clear();
			intents.clear();
			toxicity_value.clear();
			listone.clear();
			moderated.clear();
			type.clear();
			int a=0;
			int length_list;
			if(list1.size()>=5)
			{
				length_list=5;
				while(a<length_list)
				{
					listone.add(list1.get(a).toString());
					a++;
				}
			}
			else
			{
				length_list = list1.size();
				while(a<length_list)
				{
					listone.add(list1.get(a).toString());
					a++;
				}
			}
			int i =0, count=0 ; 
				while(i!=length_list)
				{	
					//sentiment detection 
					ParallelDots pd = new ParallelDots();
					String emo= pd.emotionDetect(listone.get(i).toString());
					emotions.add(emo);
					String intent = pd.intentAnalysisOld(listone.get(i).toString());
					intents.add(intent);
					String sentiment = pd.evalSentiment(listone.get(i).toString());
					sentiments.add(sentiment);
					
					
					BadWords bd = new BadWords();
					String msg = listone.get(i).toString();
					child = bd.moderateText(msg, "en");
					ArrayList<String> type_child = new ArrayList<>();
					if(child.get(0).equalsIgnoreCase("No Bad Words"))
					{
						toxicity.add("No");
						type_child.add("Appropriate");
						
					}
					else
					{
						toxicity.add("Yes");
						type_child.add("Inappropriate");
						
					}
					type.add(type_child);
					moderated.add(child);		
					i++;
					count++;
				}
		
			
		 
			model.addAttribute("moderated", moderated);
				model.addAttribute("type", type);
				model.addAttribute("original", listone);
				model.addAttribute("toxicity", toxicity);
				model.addAttribute("intent", intents);
				model.addAttribute("emotion", emotions);
				model.addAttribute("sentiment", sentiments);
				
			return "fetchFacebookTimeline";
			}
			catch(Exception e)
			{
				model.addAttribute("err", "Server overload !");
				return "fetchFacebookTimeline";
			}
		}
		
	@RequestMapping("/fetchYoutubeVideos")
	public String fetchYoutubeVideoUsingChannelID(Model model, String url){
			try {
			ArrayList<String> ar = new ArrayList<>();
			ArrayList<String> video = new ArrayList<>();
			ArrayList<String> video1 = new ArrayList<>();
			
			if(url.isEmpty())
			{
				model.addAttribute("message", "Empty String");
				return "fetchYoutubeVideos";
			}
			 url = url.trim();
			 ApiExample ae = new ApiExample();
			 String cid = ae.getChannelID(url);
			 
			 String uploadID = ae.fetchUploadIdUsingChannelId(cid, 10);
			 ar = ae.fetchVidsUsingUploadID(uploadID);
			 int i=0;
			 while(i<ar.size())
			 {
				 video.add(ar.get(i).toString());
				 video1.add(ar.get(i+1).toString());
				 i+=2;
			 }
			 fetchCommentsUsingVid(model,video1.get(0).toString());
			 
			 return "fetchYoutubeVideos";
			}
			catch(Exception e)
			{
				
				return "fetchYoutubeVideos";
			}
		}
		

		
		@RequestMapping("/fetchDataUsingFiltersYoutube")
	public String fetchDataUsingFiltersYoutube(Model model, String intent, String sentiment) throws ParseException, IOException, org.json.simple.parser.ParseException{
			
			JSONArray ar = new JSONArray();
			Database db = new Database();
			ar = db.fetchDataUsingFilterPosts1(sentiment, intent, "YoutubeResults");
			createYoutubeGraph(model,ar);
			return "youTubeCharts";
		}
		
		@RequestMapping("/fetchDataUsingFiltersFacebook")
	public String fetchDataUsingFiltersFacebook(Model model, String intent, String sentiment, String company) throws ParseException, IOException, org.json.simple.parser.ParseException{
			
			JSONArray ar = new JSONArray();
			Database db = new Database();
			ar = db.fetchDataUsingFilterPosts(sentiment, intent, "FacebookResults", company);
			createFaceBookGraph(model,ar);
			return "facebookCharts";
		}
		
		@RequestMapping("/fetchDataUsingFiltersTwitter")
	public String fetchDataUsingFiltersTwitter(Model model, String intent, String sentiment, String company) throws ParseException, IOException, org.json.simple.parser.ParseException{
			
			JSONArray ar = new JSONArray();
			Database db = new Database();
			ar = db.fetchDataUsingFilterPosts(sentiment, intent, "TwitterResults", company);
			System.out.println("size of ar="+ar.length());
			createTwitterGraph(model,ar);
			return "twitterCharts";
		}
		
		@RequestMapping("/fetchDataUsingFiltersInsta")
	public String fetchDataUsingFiltersInstagram(Model model, String intent, String sentiment) throws ParseException, IOException, org.json.simple.parser.ParseException{
			
			JSONArray ar = new JSONArray();
			Database db = new Database();
			ar = db.fetchDataUsingFilterPosts1(sentiment, intent, "InstagramResults");
			createInstagramGraph(model,ar);
			return "instagramCharts";
		}

		@RequestMapping("/fetchDataUsingFiltersCommandCenter")
	public String fetchDataUsingFiltersCommandCenter(Model model, String intent, String sentiment,String company) throws ParseException, IOException, org.json.simple.parser.ParseException{
			
			JSONArray twitterData = new JSONArray();
			JSONArray facebookData = new JSONArray();
			JSONArray youtubeData = new JSONArray();
			Database db = new Database();
			twitterData = db.fetchDataUsingFilterPosts(sentiment, intent,"TwitterResults", company);
			facebookData = db.fetchDataUsingFilterPosts(sentiment, intent, "FacebookResults", company);
			youtubeData = db.fetchDataUsingFilterPosts(sentiment, intent, "YoutubeResults", company);
			getFacebookcc(model, facebookData);
			getTwittercc(model, twitterData);
			getYoutubecc(model, youtubeData);
			return "commandCenter";
		}
		
		@RequestMapping("/saveResultsTwitter")
	public String saveResultsTwitter(Model model) throws Exception{
			
			int response;
			Database db = new Database();
			response = db.saveTwitterResults(list2, moderatedText2, intents, sentiments, emotions, image_res, toxicity, "ck");
			if(response==1)
			{
				populateCommandCenter(model);	
				model.addAttribute("response","Save Successful.");
			}
			else
			{
				populateCommandCenter(model);
				model.addAttribute("response","Not saved");
			}
			return "commandCenter";
		}
		
		@RequestMapping("/saveResultsInstagram")
	public String saveResultsInstagram(Model model) throws Exception{
			
			int response;
			Database db = new Database();
			response = db.saveInstagramResults(list1, moderatedText2, intents, sentiments, emotions, image_res, toxicity, "tommyhilfiger");
			if(response==1)
			{
				populateCommandCenter(model);	
				model.addAttribute("response","Save Successful.");
			}
			else
			{
				populateCommandCenter(model);
				model.addAttribute("response","Not saved");
			}
			return "commandCenter";
		}
		
		@RequestMapping("/saveResultsFacebook")
	public String saveResultsFacebook(Model model) throws Exception{
			
			int response;
			Database db = new Database();
			response = db.saveFacebookResults(listone, moderated, intents, sentiments, emotions, toxicity,type, "ck");
			if(response==1)
			{
				populateCommandCenter(model);	
				model.addAttribute("response","Save Successful.");
			}
			else
			{
				populateCommandCenter(model);
				model.addAttribute("response","Not saved");
			}
			return "commandCenter";
		}
		
		@RequestMapping("/saveResultsYoutube")
	public String saveResultsYoutube(Model model) throws Exception{
			
			int response;
			Database db = new Database();
			response = db.saveYoutubeResults(listone, listtwo, moderatedText2, intents, sentiments, emotions, toxicity, "t2games");
			if(response==1)
			{
				populateCommandCenter(model);	
				model.addAttribute("response","Save Successful.");
			}
			else
			{
				populateCommandCenter(model);
				model.addAttribute("response","Not saved");
			}
			return "commandCenter";
		}
		
		//populating  tweets, feeds and posts from DB depending on company
		@RequestMapping("/populateT2Tweets")
	public String populateT2Tweets(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> image = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
			
			Database db = new Database();
			response = db.getTweetsBasedOnCompany("t2games");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Tweet"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				image.add(data.getString("Image"));
				sentiment.add(data.getString("Sentiment"));
				
			}
		
			model.addAttribute("moderateText",words);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("image_res", image);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "twitterDashboard";
			}
			return "twitterDashboard";
		}
		
		@RequestMapping("/populateMandSTweets")
	public String populateMandSTweets(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> image = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
			
			Database db = new Database();
			response = db.getTweetsBasedOnCompany("marks&spencer");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Tweet"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				image.add(data.getString("Image"));
				sentiment.add(data.getString("Sentiment"));
				
			}
		
			model.addAttribute("moderateText",words);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("image_res", image);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "twitterDashboard";
			}
			return "twitterDashboard";
		}
		
		@RequestMapping("/populateAutodeskTweets")
	public String populateAutodeskTweets(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> image = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
			
			Database db = new Database();
			response = db.getTweetsBasedOnCompany("autodesk");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Tweet"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				image.add(data.getString("Image"));
				sentiment.add(data.getString("Sentiment"));
				
			}
		
			model.addAttribute("moderateText",words);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("image_res", image);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "twitterDashboard";
			}
			return "twitterDashboard";
		}
		
		@RequestMapping("/populateSkyTweets")
	public String populateSkyTweets(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> image = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
			
			Database db = new Database();
			response = db.getTweetsBasedOnCompany("sky");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Tweet"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				image.add(data.getString("Image"));
				sentiment.add(data.getString("Sentiment"));
				
			}
		
			model.addAttribute("moderateText",words);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("image_res", image);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "twitterDashboard";
			}
			return "twitterDashboard";
		}
		
		@RequestMapping("/populateUberTweets")
	public String populateUberTweets(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> image = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
	
			Database db = new Database();
			response = db.getTweetsBasedOnCompany("uber");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Tweet"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				image.add(data.getString("Image"));
				sentiment.add(data.getString("Sentiment"));
				
			}
		
			model.addAttribute("moderateText",words);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("image_res", image);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "twitterDashboard";
			}
			return "twitterDashboard";
		}
		
		@RequestMapping("/populateT2Facebook")
	public String populateT2Facebook(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> type = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
			
			
			Database db = new Database();
			response = db.getFacebookPostsBasedOnCompany("t2games");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Post"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				sentiment.add(data.getString("Sentiment"));
				String a = data.getString("Type");
				a= a.replace("[", "");
				a= a.replace("]", "");
				type.add(a);
			}
			
			model.addAttribute("moderated", words);
			model.addAttribute("type", type);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "fetchFacebookTimeline";
			}
			return "fetchFacebookTimeline";
		}
		
		@RequestMapping("/populateT2Instagram")
	public String populateT2Instagram(Model model) {
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> image = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
			
			Database db = new Database();
			response = db.getInstagramPostsBasedOnCompany("t2games");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Post"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				sentiment.add(data.getString("Sentiment"));
				image.add(data.getString("Image"));
				
			}
			
			model.addAttribute("moderateText",words);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("image_res", image);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "fetchInstaTimeline";
			}
			
			return "fetchInstaTimeline";
		}
		
		@RequestMapping("/populateTH")
	public String populateTHTweets(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> image = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
	
			Database db = new Database();
			response = db.getTweetsBasedOnCompany("tommyhilfiger");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Tweet"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				image.add(data.getString("Image"));
				sentiment.add(data.getString("Sentiment"));
				
			}
		
			model.addAttribute("moderateText",words);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("image_res", image);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "twitterDashboard";
			}
			return "twitterDashboard";
		}
		
		@RequestMapping("/populateCKFacebook")
	public String populateCKFacebook(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> type = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
			
			
			Database db = new Database();
			response = db.getFacebookPostsBasedOnCompany("ck");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Post"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				sentiment.add(data.getString("Sentiment"));
				String a = data.getString("Type");
				a= a.replace("[", "");
				a= a.replace("]", "");
				type.add(a);
			}
			
			model.addAttribute("moderated", words);
			model.addAttribute("type", type);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "fetchFacebookTimeline";
			}
			return "fetchFacebookTimeline";
		}	
		
		@RequestMapping("/populateCK")
	public String populateCKTweets(Model model){
			
			try {
			JSONArray response;
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> words = new ArrayList<>();
			ArrayList<String> intent = new ArrayList<>();
			ArrayList<String> emotion = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> image = new ArrayList<>();
			ArrayList<String> sentiment = new ArrayList<>();
	
			Database db = new Database();
			response = db.getTweetsBasedOnCompany("ck");
			int i ;
			for(i=0; i < response.length();i++)
			{
				JSONObject data = response.getJSONObject(i);
				content.add(data.getString("Tweet"));
				String s = data.getString("Words");
				s= s.replace("[", "");
				s= s.replace("]", "");
				words.add(s);
				intent.add(data.getString("Intent"));
				emotion.add(data.getString("Emotion"));
				review.add(data.getString("Review"));
				image.add(data.getString("Image"));
				sentiment.add(data.getString("Sentiment"));
				
			}
		
			model.addAttribute("moderateText",words);
			model.addAttribute("intent", intent);
			model.addAttribute("emotion", emotion);
			model.addAttribute("sentiment", sentiment);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", review);
			model.addAttribute("image_res", image);
			model.addAttribute("res", "1");
			}
			catch(Exception e)
			{
				return "twitterDashboard";
			}
			return "twitterDashboard";
		}
	
}
